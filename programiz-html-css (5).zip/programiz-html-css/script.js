const todoInput = document.getElementById("todoInput");
const addBtn = document.getElementById("addBtn");
const todoList = document.getElementById("todoList");
const pendingTasks = document.getElementById("pendingTasks");
const clearAll = document.getElementById("clearAll");

function updateCount() {
    const count = todoList.children.length;
    pendingTasks.textContent = `You have ${count} pending tasks`;
}

function addTask() {
    const taskText = todoInput.value.trim();

    if (taskText === "") {
        return;
    }

    const li = document.createElement("li");

    li.innerHTML = `
        <span>${taskText}</span>
        <button class="delete">
            <i class="fas fa-trash"></i>
        </button>
    `;

    li.querySelector(".delete").addEventListener("click", () => {
        li.remove();
        updateCount();
    });

    todoList.appendChild(li);

    todoInput.value = "";
    updateCount();
}

addBtn.addEventListener("click", addTask);

todoInput.addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        addTask();
    }
});

clearAll.addEventListener("click", () => {
    todoList.innerHTML = "";
    updateCount();
});

const demoTasks = [
    "Buy a new gaming laptop",
    "Complete a previous task",
    "Create video for YouTube",
    "Create a new portfolio site"
];

demoTasks.forEach(task => {
    const li = document.createElement("li");

    li.innerHTML = `
        <span>${task}</span>
        <button class="delete">
            <i class="fas fa-trash"></i>
        </button>
    `;

    li.querySelector(".delete").addEventListener("click", () => {
        li.remove();
        updateCount();
    });

    todoList.appendChild(li);
});

updateCount();